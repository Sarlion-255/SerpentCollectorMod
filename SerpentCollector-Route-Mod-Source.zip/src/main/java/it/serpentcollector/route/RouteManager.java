package it.serpentcollector.route;

import net.minecraft.util.math.BlockPos;
import java.util.ArrayList;
import java.util.List;

public class RouteManager {

    public static class DepositStation {
        private final BlockPos depositPos;
        private final List<BlockPos> collectorPositions;

        public DepositStation(BlockPos depositPos, List<BlockPos> collectorPositions) {
            this.depositPos = depositPos;
            this.collectorPositions = collectorPositions;
        }

        public BlockPos getDepositPos() {
            return depositPos;
        }

        public List<BlockPos> getCollectorPositions() {
            return collectorPositions;
        }
    }

    private final List<DepositStation> stations = new ArrayList<>();
    private int currentStationIndex = -1;

    public void setupRoute(BlockPos startDeposit, BlockPos endDeposit) {
        stations.clear();
        
        int stepX = Integer.compare(endDeposit.getX(), startDeposit.getX());
        int stepY = Integer.compare(endDeposit.getY(), startDeposit.getY());
        int stepZ = Integer.compare(endDeposit.getZ(), startDeposit.getZ());

        stepX = stepX == 0 ? 1 : stepX;
        stepY = stepY == 0 ? 1 : stepY;
        stepZ = stepZ == 0 ? 1 : stepZ;

        for (int x = startDeposit.getX(); x != endDeposit.getX() + stepX; x += stepX) {
            for (int y = startDeposit.getY(); y != endDeposit.getY() + stepY; y += stepY) {
                for (int z = startDeposit.getZ(); z != endDeposit.getZ() + stepZ; z += stepZ) {
                    BlockPos deposit = new BlockPos(x, y, z);
                    
                    List<BlockPos> collectors = new ArrayList<>();
                    collectors.add(deposit.add(stepX, -1, stepZ));
                    collectors.add(deposit.add(stepX * 2, -2, stepZ * 2));

                    stations.add(new DepositStation(deposit, collectors));
                }
            }
        }
        
        this.currentStationIndex = 0;
    }

    public DepositStation getCurrentStation() {
        if (currentStationIndex >= 0 && currentStationIndex < stations.size()) {
            return stations.get(currentStationIndex);
        }
        return null;
    }

    public boolean nextStation() {
        if (currentStationIndex + 1 < stations.size()) {
            currentStationIndex++;
            return true;
        }
        return false;
    }

    public boolean isRouteFinished() {
        return currentStationIndex >= stations.size();
    }

    public void reset() {
        stations.clear();
        currentStationIndex = -1;
    }
}
